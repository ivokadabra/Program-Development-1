#define _CRT_SECURE_NO_WARNINGS 1

#include <stdlib.h>
#include <stdio.h>

int main()
{

    float tempIn, tempOut;
    int unitIn, unitOut;
    int desiredConversion;
    int type;
    char response;
    int schmelzpunkt;
    int siedepunkt;


    printf("\n\nProgramm zur Umrechnung von Temperaturen\n");
    printf("----------------------------------------\n");

    do {

        printf("\nAus welchem Einheitensystem soll umgerechnet werden?\n\n");
        printf("1: grad C     2: grad F     3: K      4:R�\n\n");              //Eingabe des gew�nschtes Einheitssystems
        printf("Ihre Wahl: ");
        scanf("%i",&unitIn);
        while (getchar() != '\n');

        printf("\nBitte geben Sie die umzurechnende Temperatur an: ");
        scanf("%f",&tempIn);

      while ((unitIn == 1 && tempIn < -273.15)
	     || (unitIn == 2 && tempIn < -459.67) || (unitIn == 3
						      && tempIn < 0)
	     || (unitIn == 4 && tempIn < 0))
	     {
      printf ("Keine Werte unter den absoluten Null");    //Bedingungen f�r Begrenzung der Werten unter den absoluten Nulle.
	  printf ("\nBitte geben sie neue Werte an:");
	  scanf ("%f", &tempIn);



	     };

       while (getchar() != '\n');


        printf("\nIn welches Einheitensystem soll umgerechnet werden?\n\n");     //Eingabe des Einabensystems ,in dem der gew�nschte Temperatur umgerechnet wird.
        printf("1: grad C     2: grad F     3: K       4:R�\n\n");

        printf("Ihre Wahl: ");
        scanf("%i",&unitOut);
        while (getchar() != '\n');

        desiredConversion = unitIn * 10 + unitOut;
        switch(desiredConversion) {                                 //Berechnung der verschiedenen F�lle von Temperaturumwandlung
            case 12:
                tempOut = tempIn * 1.8 + 32.0;
                printf("\n\n%.2fgrad C = %.2fgrad F\n\n", tempIn, tempOut);
                type='F';
                schmelzpunkt=32;
                  siedepunkt=212;
                break;
            case 13:
                tempOut = tempIn + 273.15;
                printf("\n\n%.2fgrad C = %.2fK\n\n", tempIn, tempOut);
                type='K';
                 schmelzpunkt=273.15;
                  siedepunkt=373.15;
                break;
            case 14:
                tempOut = tempIn * 21 / 40 + 7.5;
                printf("\n\n%.2fgrad C = %.2fgrad R�\n\n", tempIn, tempOut);
                type='R';
                schmelzpunkt=7.5;
                  siedepunkt=60;
                break;
            case 21:
                tempOut = (tempIn - 32.0) * 5.0 / 9.0;
                printf("\n\n%.2fgrad F = %.2fgrad C\n\n", tempIn, tempOut);
                type='C';
                schmelzpunkt=0;
                  siedepunkt=100;
                break;
            case 23:
                tempOut = (tempIn - 32) * 5.0 / 9.0 + 273.15;
                printf("\n\n%.2fgrad F = %.2fK\n\n", tempIn, tempOut);
                type='K';
                 schmelzpunkt=273.15;
                  siedepunkt=373.15;
                break;
            case 24:
                tempOut = (tempIn - 32) * 7 / 24 + 7.5;
                printf("\n\n%.2fgrad F = %.2fgrad R�\n\n", tempIn, tempOut);
                type='R';
                schmelzpunkt=7.5;
                  siedepunkt=60;
                break;
            case 31:
                tempOut = tempIn - 273.15;
                printf("\n\n%.2fK = %.2fgrad C\n\n", tempIn, tempOut);
                type='C';
                schmelzpunkt=0;
                  siedepunkt=100;
                break;
            case 32:
                tempOut = (tempIn - 273.15) * 1.8 + 32;
                printf("\n\n%.2fK = %.2fgrad F\n\n", tempIn, tempOut);
                type='F';
                schmelzpunkt=32;
                  siedepunkt=212;
                break;
            case 34:
                tempOut = (tempIn - 273.15) * 21 / 40 + 7.5;
                printf("\n\n%.2fK = %.2fgrad R� \n\n", tempIn, tempOut);
                type='R';
                schmelzpunkt=7.5;
                  siedepunkt=60;
                break;
            case 41:
                tempOut = (tempIn  - 7.5)* 40 / 21;
                printf("\n\n%.2fgrad R� = %.2fgrad C \n\n", tempIn, tempOut);
                type='C';
                schmelzpunkt=0;
                  siedepunkt=100;
                break;
            case 42:
                tempOut = (tempIn - 7.5) * 24 / 7 + 32;
                printf("\n\n%.2fgrad R� = %.2fgrad F \n\n", tempIn, tempOut);
                type='F';
                schmelzpunkt=32;
                  siedepunkt=212;
                break;
            case 43:
                tempOut = (tempIn - 7.5) * 40 / 21 + 273.15;
                printf("\n\n%.2fgrad R� = %.2fK \n\n", tempIn, tempOut);
                type='K';
                 schmelzpunkt=273.15;
                  siedepunkt=373.15;
                break;
        }

    printf("----------------------------------------\n");
    for (int i=0;i<tempOut/5;i++) {
        printf("*");                                             //grapfische Vorstellung des Ergebnis(Termometer)
    }

    printf("\n----------------------------------------");
    printf("\n%d",schmelzpunkt);
    printf("%c                                        ",type);
    printf("%d",siedepunkt);
    printf("%c",type);


        printf("\n\nerneute Berechnung? (j/n)");
        scanf("%c",&response);
        while (getchar() != '\n');
    } while(response == 'j' || response == 'J'); // Schleife f�r neuen Anfang
}
